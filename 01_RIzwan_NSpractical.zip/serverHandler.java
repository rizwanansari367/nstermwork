import java.io.*;
import java.net.*;
import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;

public class ServerHandler{

	private SecretKeySpec sessionKey,secretKey;
	private File file;
	public ServerHandler(){
		String key = "!@#$%^&*";
		secretKey = new SecretKeySpec(key.getBytes(),"DES");
		file = new File("input.txt");
	}
	
	public void getSessionKeyFromKdc(InputStream sInput){
		try{
			
			DataInputStream disFromKdc = new DataInputStream(sInput);
			
			while(disFromKdc.available()==0){}
			int len = disFromKdc.readInt();
			
			while(disFromKdc.available()==0){}
			byte[] encryptedSessionKey = new byte[len];
			disFromKdc.read(encryptedSessionKey,0,len);
			
			System.out.println("encrypted session key is received......");
			
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE,secretKey);
			
			byte[] sessionKeyByte = cipher.doFinal(encryptedSessionKey);
			sessionKey = new SecretKeySpec(sessionKeyByte,"DES");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

	public void sendFileToClient(OutputStream sOutput){
		try{
			Cipher cipher = Cipher.getInstance("DES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE,sessionKey);
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file));
			CipherInputStream cis = new CipherInputStream(bis,cipher);
			DataOutputStream dosToClient = new DataOutputStream(new BufferedOutputStream(sOutput));
			dosToClient.writeUTF(file.getName());
			byte[] fileData = new byte[100];
			int no;
			while((no = cis.read(fileData))!=-1){
				dosToClient.write(fileData,0,no);
				dosToClient.flush();
			}
			
			cis.close();
			bis.close();
			dosToClient.close();
			
			System.out.println("file send to client......");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}
