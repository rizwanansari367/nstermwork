import java.io.*;
import java.net.*;

public class Server{
	public static void main(String[] args){
		try{
			ServerSocket serverSocket = new ServerSocket(3421);
			System.out.println("server getting started.......");
			
			while(true){
				Socket kdcSocket = serverSocket.accept();
				System.out.println("connected to KDC.........");
				
				InputStream kdcSInput = kdcSocket.getInputStream();
				//OutputStream KdcSOutput = KdcSocket.getOutputStream();
				
				ServerHandler s = new ServerHandler();
				s.getSessionKeyFromKdc(kdcSInput);
				kdcSocket.close();
				
				Socket clientSocket = serverSocket.accept();
				System.out.println("connected to client.......");
				
				OutputStream clientSOutput = clientSocket.getOutputStream();
				s.sendFileToClient(clientSOutput);
				
				clientSocket.close();
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
}